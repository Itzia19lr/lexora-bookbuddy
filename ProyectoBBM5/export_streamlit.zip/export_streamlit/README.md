# Modelo de Recomendación - Lexora

## Estructura de Archivos

```
export_streamlit/
├── data/
│   ├── libros.csv              # 783 libros con portadas
│   ├── usuarios.csv            # 500 usuarios
│   ├── ratings.csv             # 6215 calificaciones
│   ├── popularidad_libros.csv  # Estadísticas de popularidad
│   ├── generos.json            # 22 géneros disponibles
│   ├── stats_paginas.json      # Estadísticas de extensión
│   └── stats_años.json         # Estadísticas de época
│
└── models/
    ├── similitud_contenido.npy     # Matriz (783, 783)
    ├── similitud_item_item.npy     # Matriz (783, 783)
    ├── matriz_completa.npz         # Sparse (500, 783)
    ├── mapeos.pkl                  # Mapeos usuario/libro
    └── modelo_metadata.json        # Información del modelo
```

## Modelo

**Sistema Híbrido 70/30**
- 70% Content-Based Filtering (Vector Space Model)
- 30% Collaborative Filtering (Item-Based k-NN)

**Desempeño:**
- MAE: 0.58
- RMSE: 0.71

## Uso en Streamlit

```python
import numpy as np
import pickle
from scipy.sparse import load_npz

# Cargar matrices
similitud_contenido = np.load('models/similitud_contenido.npy')
similitud_item_item = np.load('models/similitud_item_item.npy')
matriz_completa = load_npz('models/matriz_completa.npz')

# Cargar mapeos
with open('models/mapeos.pkl', 'rb') as f:
    mapeos = pickle.load(f)
```

## Tamaño Total

Aproximadamente 9.8 MB